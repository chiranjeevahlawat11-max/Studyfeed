# StudyFeed — Android starter project

This is the first source-code milestone for StudyFeed.

## What is included
- Native Kotlin + Jetpack Compose dashboard.
- Starter NCERT Class 10 subject/chapter lists.
- Accessibility-service declaration scoped to Instagram's Android package.
- Basic Instagram window-event detection.
- No network permission and no AI API dependency.

## What is NOT implemented yet
- Posts are not hidden or blocked in this version.
- There is no automatic content classification yet.
- OCR is not connected.
- Strict mode is currently a UI preference, not an enforcement mechanism.
- Accessibility service does not read DMs or post contents.

## Open in an Android development environment
1. Extract the ZIP.
2. Open the `StudyFeed` folder as an existing Gradle project.
3. Use JDK 17.
4. Allow Gradle to sync and download Android dependencies.
5. Build and install the `app` configuration on a test device.
6. In Android Settings > Accessibility, enable "StudyFeed Instagram filter".
7. Open Instagram and inspect Android Studio Logcat for the `StudyFeed` tag.

## Build requirements
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Compile SDK 35
- Minimum Android 8.0 / API 26

## Privacy
The app currently requests no Internet permission. Its accessibility service is configured for Instagram only. The service logs screen/window events, not message contents.

## Important
The chapter list is a development starter list, not a guarantee of the current CBSE board-exam syllabus. Validate the current official syllabus before using it as a strict allowlist.

Accessibility APIs are sensitive. Keep the service limited to the stated purpose, disclose its operation clearly, and review Android/Google Play policies before distribution.

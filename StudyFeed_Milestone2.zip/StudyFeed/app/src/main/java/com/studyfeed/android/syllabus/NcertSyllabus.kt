package com.studyfeed.android.syllabus

data class Subject(val name: String, val chapters: List<String>)

object NcertSyllabus {
    // Starter list for development. Verify against the current CBSE syllabus
    // before treating this as an authoritative exam syllabus.
    val subjects = listOf(
        Subject("Science", listOf(
            "Chemical Reactions and Equations",
            "Acids, Bases and Salts",
            "Metals and Non-metals",
            "Carbon and its Compounds",
            "Life Processes",
            "Control and Coordination",
            "How do Organisms Reproduce?",
            "Heredity",
            "Light – Reflection and Refraction",
            "The Human Eye and the Colourful World",
            "Electricity",
            "Magnetic Effects of Electric Current",
            "Our Environment"
        )),
        Subject("Mathematics", listOf(
            "Real Numbers", "Polynomials", "Pair of Linear Equations in Two Variables",
            "Quadratic Equations", "Arithmetic Progressions", "Triangles",
            "Coordinate Geometry", "Introduction to Trigonometry",
            "Some Applications of Trigonometry", "Circles", "Areas Related to Circles",
            "Surface Areas and Volumes", "Statistics", "Probability"
        )),
        Subject("Social Science", listOf(
            "The Rise of Nationalism in Europe", "Nationalism in India",
            "The Making of a Global World", "The Age of Industrialisation",
            "Print Culture and the Modern World", "Resources and Development",
            "Forest and Wildlife Resources", "Water Resources",
            "Agriculture", "Minerals and Energy Resources",
            "Manufacturing Industries", "Lifelines of National Economy",
            "Power Sharing", "Federalism", "Gender, Religion and Caste",
            "Political Parties", "Outcomes of Democracy",
            "Development", "Sectors of the Indian Economy",
            "Money and Credit", "Globalisation and the Indian Economy"
        )),
        Subject("English", listOf(
            "A Letter to God", "Nelson Mandela: Long Walk to Freedom",
            "Two Stories about Flying", "From the Diary of Anne Frank",
            "The Hundred Dresses", "Glimpses of India", "Mijbil the Otter",
            "Madam Rides the Bus", "The Sermon at Benares", "The Proposal",
            "A Triumph of Surgery", "The Thief's Story", "The Midnight Visitor",
            "A Question of Trust", "Footprints Without Feet", "The Making of a Scientist",
            "The Necklace", "Bholi", "The Book That Saved the Earth"
        )),
        Subject("Hindi", listOf(
            "क्षितिज", "कृतिका", "स्पर्श", "संचयन",
            "हिंदी व्याकरण", "लेखन कौशल"
        ))
    )
}

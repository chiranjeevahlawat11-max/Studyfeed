package com.studyfeed.android.accessibility

import android.view.accessibility.AccessibilityNodeInfo

enum class InstagramSurface {
    FEED, EXPLORE, REELS, PROFILE, MESSAGES, OTHER
}

/**
 * Heuristic screen detector. Instagram UI labels/resource IDs change over time,
 * so this must be tested against the installed Instagram version.
 */
object InstagramScreenDetector {
    fun detect(root: AccessibilityNodeInfo?): InstagramSurface {
        if (root == null) return InstagramSurface.OTHER

        val labels = mutableListOf<String>()
        collectText(root, labels, depth = 0)
        val all = labels.joinToString(" ").lowercase()

        // Messages are explicitly excluded: StudyFeed must not inspect DMs.
        if (listOf("messages", "message requests", "primary", "general", "inbox")
                .any { all.contains(it) }) return InstagramSurface.MESSAGES

        if (listOf("reels", "audio", "use audio", "remix")
                .any { all.contains(it) }) return InstagramSurface.REELS

        if (listOf("explore", "search", "recent searches")
                .any { all.contains(it) }) return InstagramSurface.EXPLORE

        if (listOf("edit profile", "share profile", "your profile")
                .any { all.contains(it) }) return InstagramSurface.PROFILE

        if (listOf("home", "following", "for you")
                .any { all.contains(it) }) return InstagramSurface.FEED

        return InstagramSurface.OTHER
    }

    private fun collectText(
        node: AccessibilityNodeInfo,
        output: MutableList<String>,
        depth: Int
    ) {
        if (depth > 18 || output.size > 250) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(output::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(output::add)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectText(child, output, depth + 1)
                child.recycle()
            }
        }
    }
}

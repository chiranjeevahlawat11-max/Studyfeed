package com.studyfeed.android

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.studyfeed.android.syllabus.NcertSyllabus

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                StudyFeedHome(
                    onOpenAccessibility = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudyFeedHome(onOpenAccessibility: () -> Unit) {
    var selectedSubject by remember { mutableStateOf("Science") }
    var strictMode by remember { mutableStateOf(true) }
    val subjects = NcertSyllabus.subjects

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("StudyFeed", style = MaterialTheme.typography.titleLarge)
                        Text("Your syllabus-first Instagram filter",
                            style = MaterialTheme.typography.labelSmall)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Protection setup", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Instagram monitoring is not enabled yet. Turn on the StudyFeed service to begin screen detection.")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onOpenAccessibility, modifier = Modifier.fillMaxWidth()) {
                            Text("Open Accessibility settings")
                        }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Tune, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Filtering preferences", style = MaterialTheme.typography.titleMedium)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Strict filtering")
                                Text("Uncertain content should be hidden",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = strictMode, onCheckedChange = { strictMode = it })
                        }
                        Text(
                            if (strictMode) "Strict mode preference is ON (filtering is not active until the service is enabled and implemented)."
                            else "Strict mode preference is OFF.",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
            item {
                Text("NCERT Class 10 syllabus", style = MaterialTheme.typography.titleLarge)
                Text("Choose a subject to inspect its starter chapter list.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                ScrollableTabRow(selectedTabIndex = subjects.indexOfFirst { it.name == selectedSubject }.coerceAtLeast(0)) {
                    subjects.forEach { subject ->
                        Tab(
                            selected = selectedSubject == subject.name,
                            onClick = { selectedSubject = subject.name },
                            text = { Text(subject.name) }
                        )
                    }
                }
            }
            items(subjects.firstOrNull { it.name == selectedSubject }?.chapters.orEmpty()) { chapter ->
                ListItem(
                    leadingContent = { Icon(Icons.Default.Book, contentDescription = null) },
                    headlineContent = { Text(chapter) },
                    supportingContent = { Text("Included in the editable starter syllabus") }
                )
                HorizontalDivider()
            }
            item {
                Text(
                    "Important: this first build is a foundation. It detects Instagram screen events, but does not yet hide posts. Content filtering will be added and tested in the next milestone.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

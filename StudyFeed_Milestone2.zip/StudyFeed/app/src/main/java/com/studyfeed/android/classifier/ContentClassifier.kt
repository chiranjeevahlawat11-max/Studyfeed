package com.studyfeed.android.classifier

enum class Decision { EDUCATIONAL, UNRELATED, UNCERTAIN }

data class Classification(
    val decision: Decision,
    val matchedTopics: List<String>,
    val reason: String
)

/**
 * Offline starter classifier. It deliberately requires multiple signals;
 * a single word such as "electricity" is not enough to approve a post.
 *
 * This is a transparent rules engine, not an AI model. Improve it using
 * a labeled test set before relying on it for broad filtering.
 */
object ContentClassifier {
    private val topicTerms = mapOf(
        "Science" to listOf(
            "chemical reaction", "balanced equation", "acid", "base", "salt",
            "metal", "non-metal", "carbon compound", "covalent bond",
            "life process", "photosynthesis", "respiration", "nephron",
            "nervous system", "hormone", "reproduction", "heredity",
            "reflection", "refraction", "human eye", "electric current",
            "ohm's law", "resistance", "magnetic field", "electromagnet"
        ),
        "Mathematics" to listOf(
            "real numbers", "polynomial", "zeroes of", "quadratic equation",
            "arithmetic progression", "pair of linear equations",
            "trigonometric", "sin theta", "cos theta", "tan theta",
            "similar triangles", "coordinate geometry", "probability",
            "mean median mode", "surface area", "volume of a cone"
        ),
        "Social Science" to listOf(
            "nationalism in india", "nationalism in europe", "satyagraha",
            "civil disobedience", "federalism", "power sharing",
            "political parties", "democracy", "money and credit",
            "self help group", "globalisation", "resources and development",
            "agriculture", "manufacturing industries", "print culture"
        ),
        "English" to listOf(
            "a letter to god", "nelson mandela", "long walk to freedom",
            "two stories about flying", "anne frank", "madam rides the bus",
            "the sermon at benares", "the proposal", "the thief's story",
            "the midnight visitor", "the necklace", "bholi"
        ),
        "Hindi" to listOf(
            "क्षितिज", "कृतिका", "स्पर्श", "संचयन", "समास", "अलंकार",
            "मुहावरे", "वाच्य", "पदबंध", "रचना के आधार पर वाक्य"
        )
    )

    private val teachingSignals = listOf(
        "class 10", "class x", "cbse", "ncert", "chapter", "question",
        "solution", "explanation", "formula", "example", "definition",
        "important points", "board exam", "exercise", "प्रश्न", "उत्तर",
        "समझिए", "उदाहरण", "अध्याय"
    )

    fun classify(rawText: String): Classification {
        val text = rawText.lowercase().replace(Regex("\\s+"), " ").trim()
        if (text.length < 12) {
            return Classification(Decision.UNCERTAIN, emptyList(), "Not enough readable text")
        }

        val matched = topicTerms.filterValues { terms ->
            terms.any { text.contains(it.lowercase()) }
        }.keys.toList()

        val teachingCount = teachingSignals.count { text.contains(it) }

        return when {
            matched.isNotEmpty() && teachingCount >= 1 ->
                Classification(Decision.EDUCATIONAL, matched, "NCERT topic plus teaching signal")
            matched.size >= 2 && teachingCount >= 1 ->
                Classification(Decision.EDUCATIONAL, matched, "Multiple NCERT topics plus teaching signal")
            matched.isEmpty() ->
                Classification(Decision.UNRELATED, emptyList(), "No recognized NCERT topic")
            else ->
                Classification(Decision.UNCERTAIN, matched, "Topic mention without clear teaching context")
        }
    }
}

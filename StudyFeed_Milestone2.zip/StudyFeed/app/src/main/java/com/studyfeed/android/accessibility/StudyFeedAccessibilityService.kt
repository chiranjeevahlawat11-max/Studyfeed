package com.studyfeed.android.accessibility

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.studyfeed.android.classifier.ContentClassifier
import com.studyfeed.android.classifier.Decision

/**
 * Milestone 2: Instagram-only visible-text classification and a blocking
 * accessibility overlay for unrelated/uncertain feed surfaces.
 *
 * No screenshots, network calls, or DM inspection are performed.
 */
class StudyFeedAccessibilityService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var shield: View? = null
    private var lastSurface: InstagramSurface = InstagramSurface.OTHER
    private var lastDecision: Decision? = null
    private var lastTextHash: Int = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        Log.i(TAG, "StudyFeed service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != INSTAGRAM_PACKAGE) {
            removeShield()
            return
        }

        val root = rootInActiveWindow ?: return
        try {
            val surface = InstagramScreenDetector.detect(root)
            lastSurface = surface

            // Never inspect or block the messaging area.
            if (surface == InstagramSurface.MESSAGES || surface == InstagramSurface.OTHER ||
                surface == InstagramSurface.PROFILE) {
                removeShield()
                return
            }

            val visibleText = extractVisibleText(root)
            val hash = visibleText.hashCode()
            if (hash == lastTextHash && lastDecision != null) return
            lastTextHash = hash

            val result = ContentClassifier.classify(visibleText)
            lastDecision = result.decision
            Log.d(TAG, "Surface=$surface decision=${result.decision} reason=${result.reason}")

            if (result.decision == Decision.EDUCATIONAL) {
                removeShield()
            } else {
                showShield(
                    if (result.decision == Decision.UNRELATED)
                        "This content doesn't match your NCERT study topics."
                    else
                        "StudyFeed couldn't verify that this content is educational."
                )
            }
        } finally {
            root.recycle()
        }
    }

    private fun extractVisibleText(root: android.view.accessibility.AccessibilityNodeInfo): String {
        val parts = mutableListOf<String>()
        fun walk(node: android.view.accessibility.AccessibilityNodeInfo, depth: Int) {
            if (depth > 18 || parts.size > 250) return
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let(parts::add)
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(parts::add)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                walk(child, depth + 1)
                child.recycle()
            }
        }
        walk(root, 0)
        return parts.distinct().joinToString(" ")
    }

    private fun showShield(message: String) {
        if (shield != null) return
        val context = this
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 48, 36, 48)
            setBackgroundColor(0xFF101827.toInt())

            addView(TextView(context).apply {
                text = "StudyFeed"
                textSize = 28f
                setTextColor(0xFFFFFFFF.toInt())
                gravity = Gravity.CENTER
            })
            addView(TextView(context).apply {
                text = message
                textSize = 17f
                setTextColor(0xFFE5E7EB.toInt())
                gravity = Gravity.CENTER
                setPadding(0, 24, 0, 24)
            })
            addView(Button(context).apply {
                text = "Close Instagram"
                setOnClickListener {
                    removeShield()
                    performGlobalAction(GLOBAL_ACTION_HOME)
                }
            })
        }

        val type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        try {
            windowManager?.addView(panel, params)
            shield = panel
        } catch (e: Exception) {
            Log.e(TAG, "Unable to show StudyFeed shield", e)
        }
    }

    private fun removeShield() {
        val current = shield ?: return
        try {
            windowManager?.removeView(current)
        } catch (_: Exception) { }
        shield = null
    }

    override fun onInterrupt() {
        removeShield()
        Log.w(TAG, "StudyFeed service interrupted")
    }

    override fun onDestroy() {
        removeShield()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "StudyFeed"
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
    }
}

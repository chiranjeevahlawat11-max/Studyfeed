# StudyFeed — Milestone 2: detection + conservative shield

## New functionality
- Instagram-only accessibility event handling.
- Heuristic detection for Feed, Explore, Reels, Profile, Messages and Other.
- Explicit exclusion of detected messaging surfaces.
- Offline keyword/context classifier for starter NCERT topics.
- Full-screen accessibility overlay when a feed-like surface is unrelated or uncertain.
- "Close Instagram" action exits to Android Home; it is not an allow/bypass button.

## Important limitations
This is an experimental prototype, not a reliable finished product:
- Instagram's UI labels and accessibility tree change frequently.
- The screen detector uses heuristics and may misidentify screens.
- The rules classifier is not semantic AI and can make false decisions.
- Reels with little accessible text will usually be classified as uncertain and hidden.
- Some Instagram surfaces may not expose captions to AccessibilityNodeInfo.
- This build may block a feed screen rather than selectively hiding individual cards.
- Test on a spare/test account first. Keep Android Settings accessible so the service can be disabled if it malfunctions.
- It does not inspect direct-message content by design, but screen-label heuristics are imperfect and must be tested.

## Test
1. Build and install the APK from the project.
2. Enable StudyFeed under Android Settings > Accessibility.
3. Open Instagram and test Home, Explore, Reels, Profile and Messages.
4. Check Logcat for `StudyFeed` decisions.
5. Record false positives/false negatives before expanding the keyword list.

## Next engineering step
Replace broad screen heuristics with version-tested Instagram resource IDs and add a local labeled test corpus. Only then consider per-card overlays and OCR.

The service receives package/window events so it can remove its overlay when the user leaves Instagram; content extraction and classification are still gated to Instagram's package only.
